# -*- coding: utf-8 -*-

from odoo import models, fields, api


class InheritSaleOrder(models.Model):
    _inherit = 'sale.order'

    def product_wizard(self):
        return {
            'name': 'Select Product Pack',
            'res_model': 'custom.product.wizard',
            'view_mode': 'form',
            'target': 'new',
            'type': 'ir.actions.act_window',
            'context': {
                'default_currency_id': self.currency_id.id,
            },
        }


class InheritSaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    sub_product_ids = fields.One2many('order.line.sub.product', 'order_line_id')
    is_pack_product = fields.Boolean()
    active = fields.Boolean(default=True)

    @api.onchange('product_uom_qty')
    def retain_unit_price(self):
        if self.product_id and self.product_uom_qty:
            if self.product_id.is_product_pack and self.sub_product_ids:
                unit_price = 0
                for sub_product_line in self.sub_product_ids:
                    unit_price += sub_product_line.org_total_price
                    sub_product_line.product_qty = self.product_uom_qty * sub_product_line.product_qty_original
                self.price_unit = unit_price

    def write(self, vals_list):
        res = super(InheritSaleOrderLine, self).write(vals_list)
        if 'product_uom_qty' in vals_list:
            if self.product_id and self.product_uom_qty:
                if self.product_id.is_product_pack and self.sub_product_ids:
                    unit_price = 0
                    for sub_product_line in self.sub_product_ids:
                        unit_price += sub_product_line.org_total_price
                        sub_product_line.product_qty = self.product_uom_qty * sub_product_line.product_qty_original
                    self.price_unit = unit_price
        return res


class OrderLineSubProduct(models.Model):
    _name = 'order.line.sub.product'

    currency_id = fields.Many2one('res.currency', related='order_line_id.currency_id')
    order_line_id = fields.Many2one('sale.order.line', ondelete='cascade', required=True)
    pack_type = fields.Selection([('fix', 'Fixed Pack'), ('custom', 'Custom Pack')])
    component_id = fields.Many2one('product.component.name')
    product_id = fields.Many2one('product.product')
    name = fields.Text()
    product_qty = fields.Float()
    unit_price = fields.Monetary()
    total_price = fields.Monetary(compute="get_total_price")
    org_total_price = fields.Monetary(compute="get_total_price")
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True,
                                  domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    product_qty_original = fields.Float("Original Quantity")

    def get_total_price(self):
        for rec in self:
            rec.total_price = rec.product_qty * rec.unit_price
            rec.org_total_price = rec.product_qty_original * rec.unit_price


class InheritStockMove(models.Model):
    _inherit = 'stock.move'

    def _action_confirm(self, merge=True, merge_into=False):
        moves = self.action_extract()
        res = super(InheritStockMove, moves)._action_confirm(merge=merge, merge_into=merge_into)
        return res

    def action_extract(self):
        """ Extract pickings """
        moves_to_return = self.env['stock.move']
        moves_to_unlink = self.env['stock.move']
        phantom_moves_vals_list = []

        for move in self:
            line_id = move.sale_line_id

            if line_id and line_id.is_pack_product:
                component_ids = line_id.sub_product_ids
                for component_id in component_ids:
                    if not component_id.product_id.type in ('consu', 'product'):
                        continue
                    vals = {
                        'picking_id': move.picking_id.id,
                        'product_id': component_id.product_id.id,
                        'product_uom': component_id.product_uom.id,
                        'product_uom_qty': component_id.product_qty,
                        'state': move.state,
                        'name': move.name,
                        'company_id': move.company_id.id,
                        'description_picking': move.description_picking,
                        'location_id': move.location_id.id,
                        'location_dest_id': move.location_dest_id.id,
                        'procure_method': move.procure_method,
                        'picking_type_id': move.picking_type_id.id,
                        'partner_id': move.partner_id.id,
                        'origin': move.origin,
                        'group_id': move.group_id.id,
                        'rule_id': move.rule_id.id,
                        'sale_line_id': move.sale_line_id.id
                    }
                    phantom_moves_vals_list.append(vals)
                moves_to_unlink |= move
            else:
                moves_to_return |= move

        moves_to_unlink.sudo().unlink()
        phantom_moves = self.env['stock.move'].create(phantom_moves_vals_list)
        phantom_moves._adjust_procure_method()
        moves_to_return |= phantom_moves
        return moves_to_return
