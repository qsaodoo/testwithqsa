# -*- coding: utf-8 -*-
{
    'name': "Product Pack Sale",

    'summary': """
       Order a pack of products""",

    'description': """
        Get the product components for a base product in form form package.
    """,

    'author': 'ErpMstar Solutions',
    'category': 'Sales',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['sale_management', 'em_product_pack_base', 'sale_stock'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'wizard/wizard_view.xml',
        'report/report.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'installable': True,
    'application': True,
    'images': ['static/description/banner.jpg'],
    'price': 30,
    'currency': 'EUR',
}
