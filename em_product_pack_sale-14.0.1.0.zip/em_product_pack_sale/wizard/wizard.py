from odoo import models, fields, api
from odoo.exceptions import ValidationError


class FixProductWizard(models.TransientModel):
    _name = 'fix.product.wizard'
    _rec_name = 'product_id'

    currency_id = fields.Many2one('res.currency')
    product_id = fields.Many2one('product.product')
    product_qty = fields.Float(default=1)
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True,
                                  domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    hidden_product_qty = fields.Float(default=1)
    unit_price = fields.Monetary()
    total_price = fields.Monetary(compute='_compute_total')
    custom_product_id = fields.Many2one('custom.product.wizard')

    @api.onchange('product_id')
    def fill_details(self):
        self.unit_price = self.product_id.lst_price
        self.product_uom = self.product_id.uom_id.id

    @api.onchange('product_id', 'product_qty', 'unit_price')
    def _compute_total(self):
        for rec in self:
            rec.total_price = rec.unit_price * rec.product_qty


class CustomProductOptionWizard(models.TransientModel):
    _name = 'custom.product.option.wizard'

    currency_id = fields.Many2one('res.currency')
    custom_product_id = fields.Many2one('custom.product.wizard')
    component_id = fields.Many2one('product.component.name')
    product_id = fields.Many2one('custom.product.component')
    product_qty = fields.Float(default=1)
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True,
                                  domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.product_id.uom_id.category_id', readonly=True)
    hidden_product_qty = fields.Float(default=1)
    unit_price = fields.Monetary()
    total_price = fields.Monetary(compute='_compute_total')
    total_sum = fields.Float()

    @api.onchange('product_id')
    def fill_details(self):
        self.unit_price = self.product_id.product_id.lst_price
        self.product_uom = self.product_id.product_id.uom_id.id

    @api.onchange('product_id', 'product_qty', 'unit_price')
    def sum_total(self):
        total = 0
        for rec in self:
            total += rec.total_price
        self.total_sum = total

    @api.onchange('product_id', 'product_qty', 'unit_price')
    def _compute_total(self):
        for rec in self:
            rec.total_price = rec.unit_price * rec.product_qty


class CustomProductWizard(models.TransientModel):
    _name = 'custom.product.wizard'

    currency_id = fields.Many2one('res.currency')
    product_id = fields.Many2one('product.product', domain=[('is_product_pack', '=', True)], required=True)
    product_qty = fields.Float(default=1, required=True)
    total_price = fields.Monetary(compute='_compute_total_sum')
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True,
                                  domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)

    fix_product_ids = fields.One2many('fix.product.wizard', 'custom_product_id')
    custom_product_option_ids = fields.One2many('custom.product.option.wizard', 'custom_product_id')
    product_all_component = fields.Many2many('custom.product.option')

    @api.depends('custom_product_option_ids.total_price')
    def _compute_total_sum(self):
        total = 0
        for rec in self:
            for fp_id in rec.fix_product_ids:
                total += fp_id.total_price
            for cp_id in rec.custom_product_option_ids:
                total += cp_id.total_price
            rec.update({
                'total_price': total,
            })

    @api.onchange('product_qty')
    def _onchange_quantity(self):
        if self.product_qty:
            total = 0
            for fix_product_line_id in self.fix_product_ids:
                fix_product_line_id.product_qty = self.product_qty * fix_product_line_id.hidden_product_qty
                fix_product_line_id.total_price = fix_product_line_id.unit_price * fix_product_line_id.product_qty
                total += fix_product_line_id.total_price
            for custom_option_line_id in self.custom_product_option_ids:
                custom_option_line_id.product_qty = self.product_qty * custom_option_line_id.hidden_product_qty
                custom_option_line_id.total_price = custom_option_line_id.unit_price * custom_option_line_id.product_qty
                total += custom_option_line_id.total_price
            self.total_price = total
        else:
            raise ValidationError("Product Quantity can't be Zero")

    @api.onchange('product_id')
    def set_product_packs(self):
        fix_ls = []
        custom_ls = []
        product_components = []
        total = 0
        self.product_uom = self.product_id.uom_id
        active_order_id = self.env.context.get("active_id")
        order_id = self.env['sale.order'].search([('id', '=', active_order_id)])

        if self.product_id:
            for fix_product_component_id in self.product_id.fix_product_component_ids:
                product_total = 0
                updated_unit_price = order_id.pricelist_id.get_product_price(
                    fix_product_component_id.product_id, fix_product_component_id.product_qty,
                    order_id.partner_id, date=False,
                    uom_id=fix_product_component_id.product_uom.id)
                fix_ls.append([0, 0, {
                    'product_id': fix_product_component_id.product_id.id,
                    'unit_price': updated_unit_price,
                    'product_uom': fix_product_component_id.product_uom.id,
                    'product_qty': fix_product_component_id.product_qty,
                    'hidden_product_qty': fix_product_component_id.product_qty,
                }])
                product_total += updated_unit_price * fix_product_component_id.product_qty
                total += product_total
            for custom_product_option_id in self.product_id.custom_product_option_ids:
                default_product_id = False
                unit_price = 0
                uom_id = False
                product_total = 0
                found_default = False
                for custom_product_id in custom_product_option_id.custom_product_ids:
                    if custom_product_id.default:
                        found_default = True
                        updated_unit_price = order_id.pricelist_id.get_product_price(
                            custom_product_id.product_id, custom_product_id.product_qty,
                            order_id.partner_id, date=False,
                            uom_id=custom_product_id.product_uom.id)

                        default_product_id = custom_product_id
                        unit_price = updated_unit_price
                        uom_id = custom_product_id.product_id.uom_id.id
                        product_total += updated_unit_price * custom_product_id.product_qty
                        break
                if not found_default:
                    custom_product_id = custom_product_option_id.custom_product_ids[0]
                    updated_unit_price = order_id.pricelist_id.get_product_price(
                        custom_product_id.product_id, custom_product_id.product_qty,
                        order_id.partner_id, date=False,
                        uom_id=custom_product_id.product_uom.id)

                    default_product_id = custom_product_id
                    unit_price = updated_unit_price
                    uom_id = custom_product_id.product_id.uom_id.id
                    product_total += updated_unit_price * custom_product_id.product_qty
                total += product_total
                custom_ls.append([0, 0, {
                    'component_id': custom_product_option_id.component_id,
                    'product_id': default_product_id,
                    'unit_price': unit_price,
                    'product_uom': uom_id,
                }])
                product_components.append(custom_product_option_id.component_id.id)
        self.fix_product_ids = False
        self.fix_product_ids = fix_ls
        self.custom_product_option_ids = False
        self.custom_product_option_ids = custom_ls
        self.product_all_component = product_components
        self.total_price = total

        res = {}
        res.update({'domain': {
            'component_id': [],
        }})
        return res

    def generate_order(self):
        lst = []
        for fix_product_id in self.fix_product_ids:
            lst.append([0, 0, {
                'pack_type': "fix",
                'component_id': False,
                'product_id': fix_product_id.product_id.id,
                'product_qty': fix_product_id.product_qty,
                'product_qty_original': fix_product_id.hidden_product_qty,
                'name': fix_product_id.display_name,
                'product_uom': fix_product_id.product_uom.id,
                'unit_price': fix_product_id.unit_price,
            }])
        for custom_product_id in self.custom_product_option_ids:
            lst.append([0, 0, {
                'pack_type': "custom",
                'component_id': custom_product_id.component_id.id,
                'product_id': custom_product_id.product_id.product_id.id,
                'name': custom_product_id.display_name,
                'product_qty': custom_product_id.product_qty,
                'product_qty_original': custom_product_id.hidden_product_qty,
                'product_uom': custom_product_id.product_uom.id,
                'unit_price': custom_product_id.unit_price,
            }])
        self.env['sale.order.line'].create({
            'order_id': self.env.context.get('active_ids', False)[0],
            'product_id': self.product_id.id,
            'name': self.product_id.display_name,
            'product_uom_qty': self.product_qty,
            'product_uom': self.product_uom.id,
            'price_unit': self.total_price / self.product_qty,
            'sub_product_ids': lst,
            'active': True,
            'is_pack_product': True,
        })
