# -*- coding: utf-8 -*-
{
    'name': "Product Pack Base",

    'summary': """Generate Pack of Products""",

    'description': """
        Set the components for a base product to make a package.
    """,

    'author': 'ErpMstar Solutions',
    'category': 'Product',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['sale'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'installable': True,
    'application': True,
    'images': ['static/description/banner.jpg'],
    'price': 10,
    'currency': 'EUR',
}
