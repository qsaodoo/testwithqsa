# -*- coding: utf-8 -*-

from odoo import models, fields, api


class FixProductComponent(models.Model):
    _name = 'fix.product.component'

    product_id = fields.Many2one('product.product')
    product_qty = fields.Float(default=1)
    unit_price = fields.Float()
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True,
                                  domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    total_price = fields.Float(compute='_compute_total')
    fix_product_id = fields.Many2one('product.product')
    currency_id = fields.Many2one("res.currency", related="product_id.currency_id")
    sequence = fields.Integer()

    @api.onchange('product_id')
    def fill_details(self):
        self.unit_price = self.product_id.lst_price
        self.product_uom = self.product_id.uom_id.id

    @api.onchange('product_id', 'product_qty', 'unit_price')
    def _compute_total(self):
        for rec in self:
            rec.total_price = rec.unit_price * rec.product_qty


class CustomProductComponent(models.Model):
    _name = 'custom.product.component'
    _rec_name = 'product_id'

    product_id = fields.Many2one('product.product', required=True)
    product_qty = fields.Float(default=1, required=True)
    unit_price = fields.Float()
    product_uom = fields.Many2one('uom.uom', string='Unit of Measure', required=True,
                                  domain="[('category_id', '=', product_uom_category_id)]")
    product_uom_category_id = fields.Many2one(related='product_id.uom_id.category_id', readonly=True)
    currency_id = fields.Many2one("res.currency", related="product_id.currency_id")
    total_price = fields.Float(compute='_compute_total')
    default = fields.Boolean()
    product_for = fields.Many2one('product.component.name', required=True)

    @api.onchange('product_id')
    def fill_details(self):
        self.unit_price = self.product_id.lst_price
        self.product_uom = self.product_id.uom_id.id

    @api.onchange('default')
    def default_val(self):
        pass

    @api.onchange('product_id', 'product_qty', 'unit_price')
    def _compute_total(self):
        for rec in self:
            rec.total_price = rec.unit_price * rec.product_qty


class ProductComponentName(models.Model):
    _name = 'product.component.name'

    name = fields.Char()
    component_value_ids = fields.One2many('custom.product.component', 'product_for')


class CustomProductOption(models.Model):
    _name = 'custom.product.option'

    component_id = fields.Many2one('product.component.name')
    custom_product_ids = fields.Many2many('custom.product.component')
    custom_product_id = fields.Many2one('product.product')
    sequence = fields.Integer()


class ProductProduct(models.Model):
    _inherit = 'product.product'

    is_product_pack = fields.Boolean()
    fix_product_component_ids = fields.One2many('fix.product.component', 'fix_product_id')
    custom_product_option_ids = fields.One2many('custom.product.option', 'custom_product_id')
    pack_lst_price = fields.Float('Pack Public Price', compute='calc_product_price', digits='Product Price')

    def calc_product_price(self):
        total_price = 0
        for rec in self:
            if rec.is_product_pack:
                if rec.fix_product_component_ids:
                    for product in rec.fix_product_component_ids:
                        total_price += product.total_price
                if rec.custom_product_option_ids:
                    for option in rec.custom_product_option_ids:
                        for val in option.custom_product_ids:
                            if val.default:
                                total_price += val.total_price
                rec.lst_price = total_price
            rec.pack_lst_price = total_price
